import sys
import pandas as pd
import numpy as np
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton,QComboBox, QLineEdit,QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import plotly.express as px
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import seaborn as sns
import warnings


#Task1
class SectorPerformanceGUI(QMainWindow):
    def __init__(self, stocks_df, companies_df, index_df):
        super().__init__()
        self.stocks_df = stocks_df
        self.companies_df = companies_df
        self.index_df = index_df
        self.unique_sectors = sorted(companies_df['Sector'].unique())
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Sector Performance Analysis')
        self.setGeometry(100, 100, 1000, 800)
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(1)

        self.sector_combo = QComboBox(self)
        self.sector_combo.addItems(self.unique_sectors)
        layout.addWidget(self.sector_combo, alignment=Qt.AlignTop)

        self.from_year_input = QLineEdit(self)
        self.to_year_input = QLineEdit(self)
        self.year_error_label = QLabel('', self)
        self.year_error_label.setStyleSheet("color: red;")

        message_label = QLabel("Note: Year from 2014-2024")
        layout.addWidget(message_label)

        layout.addWidget(self.sector_combo)
        layout.addWidget(QLabel('From Year:'))
        layout.addWidget(self.from_year_input)
        layout.addWidget(QLabel('To Year:'))
        layout.addWidget(self.to_year_input)
        layout.addWidget(self.year_error_label)

        analyze_button = QPushButton('Analyze', self)
        analyze_button.clicked.connect(self.perform_sector_analysis)
        layout.addWidget(analyze_button)

        self.from_year_input.textChanged.connect(self.validate_year_input)
        self.to_year_input.textChanged.connect(self.validate_year_input)

    def validate_year_input(self):
        from_year = self.from_year_input.text()
        to_year = self.to_year_input.text()
        message = ""
        if len(from_year) == 4 and len(to_year) == 4:
            try:
                from_year = int(from_year)
                to_year = int(to_year)
                if from_year < 2014 or from_year > 2024:
                    message = "From Year should be from 2014 to 2024."
                elif to_year < 2014 or to_year > 2024:
                    message = "To Year should be from 2014 to 2024."
                elif from_year > to_year:
                    message = "'From Year' should be less than 'To Year'."
            except ValueError:
                message = "Please enter a valid 4-digit year."
        elif len(from_year) == 4 or len(to_year) == 4:
            try:
                if len(from_year) == 4:
                    from_year = int(from_year)
                    if from_year < 2014 or from_year > 2024:
                        message = "From Year should be from 2014 to 2024."
                if len(to_year) == 4:
                    to_year = int(to_year)
                    if to_year < 2014 or to_year > 2024:
                        message = "To Year should be from 2014 to 2024."
            except ValueError:
                message = "Please enter a valid 4-digit year."
        
        self.year_error_label.setText(message)
  

    def perform_sector_analysis(self):
        selected_sector = self.sector_combo.currentText()
        from_year = self.from_year_input.text()
        to_year = self.to_year_input.text()

        try:
            from_year = int(from_year)
            to_year = int(to_year)
            if from_year < 2014 or to_year > 2024 or from_year > to_year:
                raise ValueError("Year should be from 2014 to 2024 and 'From Year' should be less than 'To Year'.")
        except ValueError as e:
            QMessageBox.warning(self, 'Input Error', str(e))
            return  

        self.stocks_df['Date'] = pd.to_datetime(self.stocks_df['Date'])
        self.index_df['Date'] = pd.to_datetime(self.index_df['Date'])
        merged_df = pd.merge(self.stocks_df, self.companies_df[['Symbol', 'Sector', 'Longname']], on='Symbol', how='left')

        date_mask = (merged_df['Date'].dt.year >= int(from_year)) & (merged_df['Date'].dt.year <= int(to_year))
        sector_df = merged_df[(merged_df['Sector'] == selected_sector) & date_mask]
        sector_performance = sector_df.groupby('Date')['Close'].mean()

        index_mask = (self.index_df['Date'].dt.year >= int(from_year)) & (self.index_df['Date'].dt.year <= int(to_year))
        index_performance = self.index_df[index_mask].set_index('Date')['S&P500']

        new_fig = Figure(figsize=(10, 5))
        ax1 = new_fig.add_subplot(111)
        ax2 = ax1.twinx()  

        ax1.plot(sector_performance.index, sector_performance, label=f'{selected_sector} Sector', color='blue')
        ax2.plot(index_performance.index, index_performance, label='S&P 500 Index', color='red', alpha=0.7)

        ax1.set_xlabel('Year')
        ax1.set_ylabel(f'{selected_sector} Sector Price', color='blue')
        ax2.set_ylabel('S&P 500 Index Price', color='red')

        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')

        ax1.set_title(f'Sector Performance Analysis: {selected_sector} ({from_year}-{to_year})')

        self.plotting_window = PlottingWindow(new_fig)
        self.plotting_window.show()

#Task 2

class RevenueGrowthAnalysisGUI(QMainWindow):
    def __init__(self, stocks_df, companies_df, index_df):
        super().__init__()
        self.stocks_df = stocks_df
        self.companies_df = companies_df
        self.index_df = index_df
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Revenue Growth vs. Stock Performance Analysis')
        self.setGeometry(100, 100, 1000, 800)
        layout = QVBoxLayout()

        self.year_combo = QComboBox(self)
        self.year_combo.addItems([str(year) for year in range(2014, 2025)])  # 2025 is exclusive
        layout.addWidget(QLabel('Select Year:'))
        layout.addWidget(self.year_combo)

        analyze_button = QPushButton('Analyze', self)
        analyze_button.clicked.connect(self.perform_analysis)
        layout.addWidget(analyze_button)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

    def perform_analysis(self):

        selected_year = int(self.year_combo.currentText())
        merged_df = pd.merge(self.stocks_df, self.companies_df[['Symbol', 'Sector', 'Shortname', 'Revenuegrowth']], on='Symbol')
        merged_df['Date'] = pd.to_datetime(merged_df['Date'])
        merged_df['Year'] = merged_df['Date'].dt.year
        merged_df_filtered = merged_df[merged_df['Year'] == selected_year]

        if not merged_df_filtered.empty:
            fig = px.scatter(merged_df_filtered, x='Revenuegrowth', y='Close', color='Sector',
                            hover_data=['Shortname'],
                            title=f'Revenue Growth vs. Stock Performance ({selected_year})')
            
            
            fig.update_yaxes(title_text='Stock Performance')
            fig.update_layout(legend_title_text='Sector')
            fig.show()

        else:
            QMessageBox.warning(self, 'No Data', f'No data available for the year {selected_year}.')
          
class PlottingWindow(QMainWindow):
    def __init__(self, figure):
        super().__init__()
        self.setWindowTitle('Analysis Results')
        self.setGeometry(100, 100, 1800, 1000)  

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        self.canvas = FigureCanvas(figure)
        layout.addWidget(self.canvas)

#Task3		
class CompanyAnalysisGUI(QMainWindow):
    def __init__(self, stocks_df, companies_df):
        super().__init__()
        self.stocks_df = stocks_df
        self.companies_df = companies_df
        self.initUI()

    def initUI(self):
        self.setWindowTitle('3. Company Analysis(Top 10 & Worst 10)')
        self.setGeometry(100, 100, 1000, 800)
        layout = QVBoxLayout()
 
        self.year_combo = QComboBox(self)
        self.year_combo.addItems([str(year) for year in range(2014, 2025)])  
        layout.addWidget(QLabel('Select Year:'))
        layout.addWidget(self.year_combo)

        analyze_button = QPushButton('Analyze', self)
        analyze_button.clicked.connect(self.company_analysis)
        layout.addWidget(analyze_button)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

    def company_analysis(self):
         
        selected_year = int(self.year_combo.currentText())
        merged_df = pd.merge(self.stocks_df, self.companies_df[['Symbol', 'Shortname', 'Revenuegrowth', 'Currentprice', 'Fulltimeemployees']], on='Symbol')
        merged_df['Date'] = pd.to_datetime(merged_df['Date'])
        merged_df = merged_df[(merged_df['Date'].dt.year == selected_year)]

        if not merged_df.empty:
            merged_df['EBITDA'] = merged_df['Currentprice'] * merged_df['Fulltimeemployees']
            merged_df['EBITDA Margin'] = merged_df['EBITDA'] / merged_df['Revenuegrowth']

            revenue_growth = merged_df.groupby('Symbol')['Revenuegrowth'].mean()
            market_capitalization = merged_df.groupby('Symbol').apply(lambda x: x['Currentprice'].iloc[-1] * x['Fulltimeemployees'].iloc[-1])
            ebitda_margin = merged_df.groupby('Symbol')['EBITDA Margin'].mean()
            average_volume = merged_df.groupby('Symbol')['Volume'].mean()

            metrics_df = pd.DataFrame({
                'Shortname': merged_df.groupby('Symbol')['Shortname'].first(),
                'Revenuegrowth': revenue_growth,
                'Marketcap': market_capitalization,
                'Ebitda_margin': ebitda_margin,
                'Average_volume': average_volume
            })

            metrics_df['Revenuegrowth_rank'] = metrics_df['Revenuegrowth'].rank(ascending=False)
            metrics_df['Marketcap_rank'] = metrics_df['Marketcap'].rank(ascending=False)
            metrics_df['Ebitda_margin_rank'] = metrics_df['Ebitda_margin'].rank(ascending=False)
            metrics_df['Average_volume_rank'] = metrics_df['Average_volume'].rank(ascending=False)

            metrics_df['Company Name'] = merged_df.groupby('Symbol')['Shortname'].first()
            metrics_df['Combined_rank'] = metrics_df[['Revenuegrowth_rank', 'Marketcap_rank', 'Ebitda_margin_rank', 'Average_volume_rank']].sum(axis=1)
            metrics_df = metrics_df.sort_values(by='Combined_rank')

            top_10 = metrics_df.head(10)
            worst_10 = metrics_df.tail(10)
            top_and_worst_10 = pd.concat([top_10, worst_10])

            print("Top 10 Companies:")
            print(top_10[['Company Name', 'Combined_rank']])
            print("Worst 10 Companies:")
            print(worst_10[['Company Name', 'Combined_rank']])

            plt.figure(figsize=(10, 6))
            colors = ['green'] * 10 + ['red'] * 10 
            plt.bar(top_and_worst_10['Company Name'], top_and_worst_10['Combined_rank'], color=colors)
            plt.xlabel('Company Name')
            plt.ylabel('Combined Ranking')
            plt.title(f'Top 10 and Worst 10 Companies by Combined Ranking ({selected_year})')
            plt.xticks(rotation=45, ha='right') 
            plt.tight_layout()
            plt.show()
        else:
            QMessageBox.warning(self, 'No Data', f'No data available for the year {selected_year}.')

#Task4
class MonthlyStockAnalysisGUI(QMainWindow):
    def __init__(self, stock_df, companies_df):
        super().__init__()
        self.stock_df = stock_df
        self.companies_df = companies_df
        self.initUI()
        stocks_df['Date'] = pd.to_datetime(stocks_df['Date'])

    def initUI(self):
        self.setWindowTitle('Stock Analysis')
        self.setGeometry(100, 100, 1000, 800)
        layout = QVBoxLayout()

        self.company_combo = QComboBox()
        self.company_combo.addItems(self.companies_df['Shortname'])
        layout.addWidget(QLabel('Select Company:'))
        layout.addWidget(self.company_combo)

        self.month_combo = QComboBox()
        self.month_combo.addItems([str(i) for i in range(1, 13)])
        layout.addWidget(QLabel('Enter Month (1-12):'))
        layout.addWidget(self.month_combo)

        self.year_combo = QComboBox(self)
        self.year_combo.addItems([str(year) for year in range(2014, 2025)])  # 2025 is exclusive
        layout.addWidget(QLabel('Select Year:'))
        layout.addWidget(self.year_combo)

        analyze_button = QPushButton('Analyze')
        analyze_button.clicked.connect(self.analyze_stock)
        layout.addWidget(analyze_button)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

    def analyze_stock(self):
        company_shortname = self.company_combo.currentText()
        company_symbol = self.companies_df[self.companies_df['Shortname'] == company_shortname]['Symbol'].values[0]
        month = int(self.month_combo.currentText())
        year = int(self.year_combo.currentText())

        filtered_stock = self.stock_df[(self.stock_df['Symbol'] == company_symbol) & 
                                       (self.stock_df['Date'].dt.month == month) & 
                                       (self.stock_df['Date'].dt.year == year)]

        if not filtered_stock.empty:

            high_price = filtered_stock['High'].max()
            low_price = filtered_stock['Low'].min()
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=filtered_stock['Date'], y=filtered_stock['High'], mode='lines', name='High Price'))
            fig.add_trace(go.Scatter(x=filtered_stock['Date'], y=filtered_stock['Low'], mode='lines', name='Low Price'))

            if not filtered_stock['High'].isnull().all():
                fig.add_annotation(x=filtered_stock.loc[filtered_stock['High'].idxmax()]['Date'], 
                                   y=high_price, 
                                   text=f'Highest Price: {high_price}', 
                                   showarrow=True, 
                                   arrowhead=1)
            if not filtered_stock['Low'].isnull().all():
                fig.add_annotation(x=filtered_stock.loc[filtered_stock['Low'].idxmin()]['Date'], 
                                   y=low_price, 
                                   text=f'Lowest Price: {low_price}', 
                                   showarrow=True, 
                                   arrowhead=1)

            fig.update_layout(title=f'Stock Prices for {company_shortname} - {month}/{year}',
                              xaxis_title='Date',
                              yaxis_title='Price')

            fig.show()
        else:
            QMessageBox.warning(self, 'No Data', 'Data available only until 02-2024')
#Task5

class ESGPerformanceGUI(QMainWindow):
    def __init__(self, esg_df):
        super().__init__()
        self.esg_df = esg_df
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Sector-wise ESG Scores')
        self.setGeometry(100, 100, 1000, 800)

        layout = QVBoxLayout()
        self.display_button = QPushButton('ESG Scores')
        self.display_button.clicked.connect(self.display_esg_scores)
        layout.addWidget(self.display_button)
        self.display_button = QPushButton('Analyze ESG by Sector')
        self.display_button.clicked.connect(self.analyze_esg_by_sector)
        layout.addWidget(self.display_button)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

    def analyze_esg_by_sector(self):
        sector_avg_esg = self.esg_df.groupby('Sector').agg({
            'Environment Risk Score': np.mean,
            'Social Risk Score': np.mean,
            'Governance Risk Score': np.mean
        }).reset_index()


        fig = go.Figure(data=[
            go.Bar(name='Environment', x=sector_avg_esg['Sector'], y=sector_avg_esg['Environment Risk Score']),
            go.Bar(name='Social', x=sector_avg_esg['Sector'], y=sector_avg_esg['Social Risk Score']),
            go.Bar(name='Governance', x=sector_avg_esg['Sector'], y=sector_avg_esg['Governance Risk Score'])
        ])

     
        fig.update_layout(
            barmode='group',
            title='Average ESG Scores by Sector',
            xaxis_title='Sector',
            yaxis_title='Average Score'
        )

        fig.update_xaxes(title_text='Sector')
        fig.update_yaxes(title_text='Average ESG Score')

        fig.show()   

    def display_esg_scores(self):
        custom_colors = {
            'Environment Risk Score': 'rgb(31, 119, 180)',
            'Governance Risk Score': 'rgb(255, 127, 14)',
            'Social Risk Score': 'rgb(44, 160, 44)'
        }

        fig_sector = px.scatter_3d(self.esg_df, x='Environment Risk Score', y='Governance Risk Score', z='Social Risk Score',
                                   color='Sector',
                                   title='Sector-wise ESG Scores',
                                   labels={'x': 'Environment Risk Score', 'y': 'Governance Risk Score', 'z': 'Social Risk Score'},
                                   color_discrete_map=custom_colors,
                                   hover_name='Sector',
                                   hover_data={'Symbol': True, 'Name': True, 'Industry': True})

        fig_sector.show()

#Task6

class CorrelationAnalysisGUI(QMainWindow):
    def __init__(self, stocks_df, companies_df):
        super().__init__()
        self.stocks_df = stocks_df
        self.companies_df = companies_df
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Correlation Analysis of Sector Returns')
        self.setGeometry(100, 100, 1000, 800)
        layout = QVBoxLayout()

        analyze_button = QPushButton('Analyze Correlation', self)
        analyze_button.clicked.connect(self.plot_correlation_matrix)
        layout.addWidget(analyze_button)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

    def plot_correlation_matrix(self):
        merged_data = pd.merge(self.stocks_df, self.companies_df[['Symbol', 'Sector']], on='Symbol', how='left')
        merged_data.sort_values(by=['Symbol', 'Date'], inplace=True)
        merged_data['Returns'] = merged_data.groupby('Symbol')['Adj Close'].pct_change()
        sector_returns = merged_data.pivot_table(index='Date', columns='Sector', values='Returns', aggfunc='mean')
        correlation_matrix_sectors = sector_returns.corr()

        fig, ax = plt.subplots(figsize=(10, 8))
        sns.heatmap(correlation_matrix_sectors, annot=True, cmap='coolwarm', center=0, ax=ax)
        ax.set_title('Correlation Matrix of Sector Returns 2014-2024')

        plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
                 rotation_mode="anchor", fontsize=10)  
        plt.setp(ax.get_yticklabels(), rotation=0, fontsize=10)  
        plt.tight_layout()  

        self.plot_window = PlottingWindow(fig)
        self.plot_window.show()

			
class MainWindow(QMainWindow):
    def __init__(self, stocks_df, companies_df, index_df,esg_df):
        super().__init__()
        self.stocks_df = stocks_df
        self.companies_df = companies_df
        self.index_df = index_df
        self.esg_df = esg_df
        self.initUI()
        
    def initUI(self):
        self.setWindowTitle('Stock Analysis - S&P 500')
        self.setGeometry(100, 100, 1000, 800)
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        heading_label = QLabel('Stock Analysis - S&P 500', self)
        heading_label.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        heading_label.setFont(QFont('Arial', 16, QFont.Bold))
        layout.addWidget(heading_label)
        
        sector_analysis_button = QPushButton('1. Sector Performance Analysis', self)
        sector_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        sector_analysis_button.clicked.connect(self.open_sector_performance_analysis)
        layout.addWidget(sector_analysis_button)
        layout.setAlignment(Qt.AlignCenter)

        revenue_growth_analysis_button = QPushButton('2. Revenue Growth vs. Stock Performance Analysis', self)
        revenue_growth_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        revenue_growth_analysis_button.clicked.connect(self.open_revenue_growth_analysis)
        layout.addWidget(revenue_growth_analysis_button)

        company_analysis_button = QPushButton('3. Company Analysis(Top 10 & Worst 10)', self)
        company_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        company_analysis_button.clicked.connect(self.open_company_growth_analysis)
        layout.addWidget(company_analysis_button)

        monthly_analysis_button = QPushButton('4. Monthly Stock Analysis', self)
        monthly_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        monthly_analysis_button.clicked.connect(self.open_monthly_analysis)
        layout.addWidget(monthly_analysis_button)

        esg_analysis_button = QPushButton('5. ESG Performance Analysis', self)
        esg_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        esg_analysis_button.clicked.connect(self.open_esg_analysis)
        layout.addWidget(esg_analysis_button)

        correlation_analysis_button = QPushButton('6. Correlation of Sector Returns', self)
        correlation_analysis_button.setFont(QFont('Arial', 14, QFont.Bold))
        correlation_analysis_button.clicked.connect(self.open_correlation_analysis)
        layout.addWidget(correlation_analysis_button)
		
    def open_sector_performance_analysis(self):
        self.sector_performance_window = SectorPerformanceGUI(self.stocks_df, self.companies_df, self.index_df)
        self.sector_performance_window.show()       

    def open_revenue_growth_analysis(self):
        self.revenue_growth_window = RevenueGrowthAnalysisGUI(self.stocks_df, self.companies_df, self.index_df)
        self.revenue_growth_window.show()   

    def open_company_growth_analysis(self):
        self.company_analysis_window = CompanyAnalysisGUI(self.stocks_df, self.companies_df)
        self.company_analysis_window.show()
		
    def open_monthly_analysis(self):
        self.monthly_analysis_window = MonthlyStockAnalysisGUI(self.stocks_df, self.companies_df)
        self.monthly_analysis_window.show()		

    def open_esg_analysis(self):
        self.esg_performance_window = ESGPerformanceGUI(self.esg_df)
        self.esg_performance_window.show()	

    def open_correlation_analysis(self):
        self.correlation_analysis_window = CorrelationAnalysisGUI(self.stocks_df, self.companies_df)
        self.correlation_analysis_window.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)

stocks_file_path = "sp500_stocks.csv"
companies_file_path = "sp500_companies.csv"
index_file_path = "sp500_index.csv"
esg_file_path = "SP 500 ESG Risk Ratings.csv"

stocks_df = pd.read_csv(stocks_file_path)
companies_df = pd.read_csv(companies_file_path)
index_df = pd.read_csv(index_file_path)
esg_df = pd.read_csv(esg_file_path)

main_window = MainWindow(stocks_df, companies_df, index_df, esg_df)
main_window.show()
warnings.simplefilter(action='ignore', category=FutureWarning)
app.exec_()
del app
