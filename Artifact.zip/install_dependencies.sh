#!/bin/bash

# Navigate to the directory containing the script and requirements.txt
cd "$(dirname "$0")"

# Update package lists to ensure you get the latest version of python3-pyqt5
echo "Updating package lists..."
sudo apt-get update

# Install python3-pyqt5 package
echo "Installing python3-pyqt5..."
sudo apt-get install -y python3-pyqt5

# Check if python3-pyqt5 installation was successful
if [ $? -eq 0 ]; then
    echo "python3-pyqt5 installed successfully."
else
    echo "Failed to install python3-pyqt5. Please check the error messages above."
    exit 1
fi

# Install Python packages from requirements.txt
echo "Installing Python packages from requirements.txt..."
pip install -r requirements.txt

# Check if the installation of Python packages was successful
if [ $? -eq 0 ]; then
    echo "Python packages installed successfully."
else
    echo "Failed to install Python packages. Please check the error messages above."
    exit 1
fi

