| Author        |     Keerthana Mohan Raj |
| ------------- | ------------- |
| Matrikelnummer|   5581522            |

## PROJECT 1
# Python Code Analysis Tools 

This Visual Studio Code extension provides a comprehensive suite of tools for analyzing and enhancing the quality of Python code according to PEP 8 guidelines. It integrates several powerful tools to lint, format, and analyze the code quality, including checking for cyclomatic complexity, maintainability index, and raw metrics.

## Requirements

1.VS Code

2.Python `3.10` (recommended)

3.Library packages

## How to Use

# Method 1
1.Clone the repo

2.Install VS code - Select `.deb ` file for ubuntu

3.Install Python `3.10` (recommended)

4.Run `sudo chmod +x ./install_dependencies.sh` then run  `sudo ./install_dependencies.sh` in the terminal from the location.It will install all the necessary packages.

5.For manual installation of packages `pip install isort black flake8 radon pandas numpy pyqt5 matplotlib plotly seaborn warnings`
  
6.Check once for python3-pyqt5 is installed.

7.Open VS code - search for **Python Analysis Tools** in extension - Install 

8.Open `"Project1\PEP8\test.py"` and save.

On installing **Python Analysis Tools** and opening test.py ,Extension activated will be printed in the output.Then by saving the file ,it will start to analyze the file.You will see the results in the output.


# Method 2
1.Clone the repo

2.Install VS code - Select `.deb ` file for ubuntu

3.Install Python `3.10` (recommended)

4.Run `sudo chmod +x ./install_dependencies.sh` then run  `sudo ./install_dependencies.sh` in the terminal from the location.It will install all the necessary packages.

5.For manual installation of packages `pip install isort black flake8 radon pandas numpy pyqt5 matplotlib plotly seaborn warnings`
  
6.Check once for python3-pyqt5 is installed.

7.Open vs code - Extensions - Install from VSIX - select `"Project1\python-analysis-tools-1.0.0.vsix"`

8.Open `"Project1\PEP8\test.py"` and save.

Extension activated will be printed in the output.Then by saving the file ,it will start to analyze the file.You will see the results in the output.

## Analyzing python file
1.You can configure the extension to run the full analysis automatically whenever you  `save` a Python file.

2.The extension provides a set of commands accessible through the Visual Studio Code Command Palette  using `CTRL+SHIFT+P`:

- Run `Lint Python File` to lint the currently open Python file.
- Run `Format Python File` to format and sort the currently open Python file.
- Run `Analyze Python Code Quality` for code quality analysis - cyclomatic complexity, maintainability and raw metrices.
- Run `Start Full Python Analysis Workflow` to trigger the full analysis workflow, which includes linting, formatting, import sorting, and code quality analysis.

For Testing: I have provided a code snippet to test
```bash
def calculate_area(radius):
    area = 3.1415 * radius ** 2
    return area

def print_results():
    results = calculate_area(5)
    print("The area is:", results)



if __name__ == "__main__":
    print_results();
```

Here when you save this code you will have some linting issues(blank lines,semicolon) and formatting issues.When you again save the file the issue will be resolved.

Enjoy a seamless Python coding experience with enhanced readability and maintainability!


## PROJECT 2

# S&P Stock Analysis 

## Overview
This Python application is a comprehensive analysis tool designed for visualizing and analyzing the performance of stocks of S&P 500 companies from 2014-2024.
## How to Use

# Method 1
1.Clone the repo

2.Install VS code - Select `.deb ` file for ubuntu

3.Install Python `3.10` (recommended)

4.Run `sudo chmod +x ./install_dependencies.sh` then run  `sudo ./install_dependencies.sh` in the terminal from the location.It will install all the necessary packages.

5.For manual installation of packages `pip install isort black flake8 radon pandas numpy pyqt5 matplotlib plotly seaborn warnings`
  
6.Check once for python3-pyqt5 is installed.

7.Run `"Project2\Py_GUI_Analysis.py"` from the file location. Make sure all 4 csv files are present in the location.

 Command: `python3 Py_GUI_Analysis.py`
 
8.A GUI will be opened where 6 analysis of S&P 500 stocks from 2014-2024 are done.

9.Select an analysis type from the main window and input the required parameters (e.g., sector, years, company). Click the analyze button to view the results.

## Note
- The application handles basic data validation, such as checking for valid year inputs. Ensure your inputs are within the expected ranges.
- Some analyses takes time, wait till the results load in the browser. Incase if it asks wait/force quit .Click `wait` and it will be loaded in seconds.

## Key Features
1. **Sector Performance Analysis**: Visualize the average stock price performance of different sectors over selected years compared to the S&P 500 index.
2. **Revenue Growth vs. Stock Performance Analysis**: Explore the correlation between revenue growth and stock performance for selected years.
3. **Company Analysis**: Identify top and worst-performing companies based on combined rankings of revenue growth, market capitalization, EBITDA margin, and average volume.
4. **Monthly Stock Analysis**: Analyze the high and low stock prices of a selected company for a given month and year.
5. **ESG Performance Analysis**: Evaluate sector-wise ESG scores and compare them to identify trends in environmental, social, and governance factors.
6. **Correlation of Sector Returns**: Examine the correlation between returns of different sectors within the S&P 500 index.
